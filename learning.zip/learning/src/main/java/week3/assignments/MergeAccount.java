package week3.assignments;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;

public class MergeAccount {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
	//	1. Launch URL and maximize the window
		driver.get("http://leaftaps.com/opentaps/control/login");
		driver.manage().window().maximize();
	//	2. Enter UserName and Password Using Id Locator
		driver.findElementById("username").sendKeys("Demosalesmanager");
		driver.findElementById("password").sendKeys("crmsfa");
		Thread.sleep(5000);
   // 3. Click on Login Button using Class Locator
		driver.findElementByClassName("decorativeSubmit").click();
   // 4. Click on CRM/SFA Link
		driver.findElementByLinkText("CRM/SFA").click();
   //   5. Click on contacts Button
		driver.findElementByXPath("//a[text()='Contacts']").click();
   //    * 6. Click on Merge Contacts using Xpath Locator
		driver.findElementByXPath("//a[text()='Merge Contacts']").click();
		 
	//	 * 7. Click on Widget of From Contact
		driver.findElementByXPath("//img[@alt='Lookup']").click();
		
		 
	//	 * 8. Click on First Resulting Contact
//		Window Handling Code
		String parentHandle = driver.getWindowHandle();
        System.out.println(parentHandle);
        
		Set<String> windowHandles = driver.getWindowHandles();
		//Set<String> winSet = driver.getWindowHandles();
		List<String> winLis	= new ArrayList<String>(windowHandles);
		driver.switchTo().window(winLis.get(1));
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
		
		//driver.close();
	driver.switchTo().window(parentHandle);
	System.out.println(driver.getTitle());
		 
	//	 * 9. Click on Widget of To Contact
		driver.findElementByXPath("//span[text()='To Contact']/following::a").click();
		//Alert alert = driver.switchTo().alert();
		//alert.accept();
		
		
		 
	//	 * 10. Click on Second Resulting Contact
	Set<String> windowHandles1 = driver.getWindowHandles();
	Set<String> winSet = driver.getWindowHandles();
	List<String> winLis1	= new ArrayList<String>(windowHandles1);
	driver.switchTo().window(winLis1.get(1));
	System.out.println(driver.getTitle());
	driver.findElementByXPath("//div[@class='x-grid3-row    x-grid3-row-alt']//a").click();
	driver.switchTo().window(parentHandle);
	System.out.println(driver.getTitle());
		//driver.close();
		 
	//	 * 11. Click on Merge button using Xpath Locator
	driver.findElementByXPath("//a[text()='Merge']").click();
		  
	//	 * 12. Accept the Alert
	Alert alert = driver.switchTo().alert();
	alert.accept();
		  
	//	 * 13. Verify the title of the page
	System.out.println(driver.getTitle());
	driver.close();
		 

	}

}
