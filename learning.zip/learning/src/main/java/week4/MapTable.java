package week4;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MapTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Launching Chrome Browser
		ChromeDriver driver = new ChromeDriver();
		//To Load the url
		driver.get("https://erail.in/");
		//To maximize the browser
		driver.manage().window().maximize();
		//implicitly wait
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementById("txtStationFrom").clear();
		driver.findElementById("txtStationFrom").sendKeys("MAS",Keys.TAB);
		driver.findElementById("txtStationTo").clear();
		driver.findElementById("txtStationTo").sendKeys("SBC",Keys.TAB);
		WebElement table = driver.findElementByXPath("//table[@class='DataTable TrainList TrainListHeader']");
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		int size = rows.size();
		System.out.println("row size "+size);
		Map<String, String> map = new LinkedHashMap<String, String>();
		System.out.println(rows.size());

		for (int i = 0; i < size; i++) {
			List<WebElement> cols = rows.get(i).findElements(By.tagName("td"));
//			List<WebElement> firstRowCols = firstRow.findElements(By.tagName("td"));
			for (int j = 0; j < cols.size() ; j++) {
			String trainName = cols.get(1).getText();
			System.out.println(trainName);
			String trainnumber = cols.get(0).getText();
			System.out.println(trainnumber);
			map.put(trainName, trainnumber);
			System.out.println(map);
			
				
			}
			
		}
	
	}

}
