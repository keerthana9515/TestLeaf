package week4;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class LearnOccur {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input="Most Important";
		Character ch='t';
		int count =0;
		Map<Character, Integer> map =new LinkedHashMap<Character, Integer>();
		char[] charArray = input.toCharArray();
		for(char c : charArray) {
			if(c==ch) {
				count++;
				map.put(c, count);
			}
		}
		
		for(Entry<Character, Integer> mapitems : map.entrySet()) {
			System.out.println(mapitems);

		}

	}

}
