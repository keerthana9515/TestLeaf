package week2assignments;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Button {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
	//	1. Launch URL and maximize the window
		driver.get("http://leafground.com/pages/Button.html");
		driver.manage().window().maximize();
//2. click on "Go to Home Page" button
		driver.findElementById("home").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//img[@alt='Buttons']").click();
	//3 Find position of button (x,y)
		//3.1 First locate the element
		WebElement eleposition = driver.findElementById("position");
		//3.2 Use point class to get position of X and Y
		
		Point position=eleposition.getLocation();
		
		int X=position.getX();
		
		int Y=position.getY();
		
		System.out.println("The Position of X and Y is: "+ X +" and " +Y);
	//4. Find colour of Radio button
		
		WebElement color = driver.findElementById("color");
	///String style = color.getCssValue("style");
	//	System.out.println(style);
		
		driver.close();
		
		
	}

}
