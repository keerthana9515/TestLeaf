package week2.day2;

import java.awt.Desktop.Action;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class select {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
	//	1. Launch URL and maximize the window
		driver.get("http://leafground.com/pages/selectable.html");
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement eleitem1 = driver.findElementByXPath("//li[text()='Item 1']");
		WebElement eleitem2 = driver.findElementByXPath("//li[text()='Item 6']");
		Actions builder = new Actions(driver);
		builder.clickAndHold(eleitem1).clickAndHold(eleitem2).release().perform();
		
		

	driver.quit();
	}
  
}
