package week2.day2;

import java.awt.Desktop.Action;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Drag {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
	//	1. Launch URL and maximize the window
		driver.get("http://leafground.com/pages/drop.html");
		driver.manage().window().maximize();
	WebElement eledrag = driver.findElementById("draggable");
	WebElement eledrop = driver.findElementById("droppable");
	Actions builder =new Actions(driver);
	builder.dragAndDrop(eledrag, eledrop).perform();
	}

}
