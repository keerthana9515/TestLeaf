package learning;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class dropdown {
@Test
	public  void dropdown1() throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
	//	1. Launch URL and maximize the window
		driver.get("http://leaftaps.com/opentaps/control/login");
		driver.manage().window().maximize();
	//	2. Enter UserName and Password Using Id Locator
		driver.findElementById("username").sendKeys("Demosalesmanager");
		driver.findElementById("password").sendKeys("crmsfa");
		Thread.sleep(5000);
   // 3. Click on Login Button using Class Locator
		driver.findElementByClassName("decorativeSubmit").click();
   // 4. Click on CRM/SFA Link
		driver.findElementByLinkText("CRM/SFA").click();
   // 5. Click on Leads Button
		driver.findElementByXPath("//a[text()='Leads']").click();
   // 6. Click on create Lead Button(ask doubt)
		driver.findElementByXPath("//a[text()='Create Lead']").click();
	//	Get the Title of the resulting Page
		String title = driver.getTitle();
		System.out.println("The title of the page id " + title);
   // 7. Enter CompanyName using id Locator
		driver.findElementById("createLeadForm_companyName").sendKeys("TestLeaf");
   // 8. Enter FirstName using id Locator
		driver.findElementById("createLeadForm_firstName").sendKeys("Test");
   // 9. Enter LastName using id Locator
		driver.findElementById("createLeadForm_lastName").sendKeys("Leaf");
		
		

	}

}
