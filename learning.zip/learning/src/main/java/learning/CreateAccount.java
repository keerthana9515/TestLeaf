package learning;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class CreateAccount {
	@Test

	public void CreateAcc(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
	//	1. Launch URL and maximize the window
		driver.get("http://leaftaps.com/opentaps/control/login");
		driver.manage().window().maximize();
	//	2. Enter UserName and Password Using Id Locator
		driver.findElementById("username").sendKeys("Demosalesmanager");
		driver.findElementById("password").sendKeys("crmsfa");
		Thread.sleep(5000);
   // 3. Click on Login Button using Class Locator
		driver.findElementByClassName("decorativeSubmit").click();
   // 4. Click on CRM/SFA Link
		driver.findElementByLinkText("CRM/SFA").click();
//Click on Find Leads
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Find Leads").click();
		driver.findElementByLinkText("Phone").click();
		driver.findElementByName("phoneNumber").sendKeys("9");
		driver.findElementByLinkText("Find Leads").click();
		Thread.sleep(5000);
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a[1]").click();
		driver.findElementByLinkText("Edit").click();
		driver.findElementByXPath("//input[@id='updateLeadForm_companyName']").clear();
		driver.findElementByXPath("//input[@id='updateLeadForm_companyName']").sendKeys("CTS");
		driver.findElementByClassName("smallSubmit").click();
		//driver.close();
	


}
	
}





