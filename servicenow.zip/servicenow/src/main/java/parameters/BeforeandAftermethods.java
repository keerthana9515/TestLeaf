package parameters;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class BeforeandAftermethods {
	public ChromeDriver driver;
@BeforeMethod
@Parameters({"url", "uname", "pass"})
	public void login(String url,String uname,String pass) {
	
	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	driver=new ChromeDriver();
	driver.get(url);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.switchTo().frame("gsft_main");
	driver.findElementById("user_name").sendKeys(uname);
	driver.findElementById("user_password").sendKeys(pass);
	driver.findElementById("sysverb_login").click();
	driver.switchTo().defaultContent();
	
	
	
}	
@AfterMethod

 public void logout() {
	
//driver.close();
driver.quit();
	


	}

}
