package incidentmanagement;


import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.Test;
import parameters.BeforeandAftermethods;

@Test
public class CreateIncident extends BeforeandAftermethods{

public void TC001createticket() {
		
//3. Enter Incident in filter navigator and press enter
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS );
//3.1 search keyword"Incidents" in filter and click on Incident result
			driver.findElementById("filter").sendKeys("Incident");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS );
			driver.findElementByXPath("(//div[@class='sn-widget-list-title' and contains(text(), 'Incidents')])[1]").click();
//4. Click on Create new option and fill the mandatory fields
//4.1  To click on new button in incident
			driver.switchTo().frame("gsft_main");
			driver.findElementById("sysverb_new").click();
//4.2 after click on new button
			driver.findElementById("lookup.incident.caller_id").click();
//Window Handling Code
			Set<String> window = driver.getWindowHandles();
			List<String> winLis	= new ArrayList<String>(window);
			driver.switchTo().window(winLis.get(1));	
//4.3 click on new in users window
			driver.findElementById("sysverb_new").click();
			driver.findElementById("sys_user.first_name").sendKeys("Keerthana");
			driver.findElementById("sys_user.email").sendKeys("xyz@def.com");
			//driver.findElementById("lookup.sys_user.title").click();
			//driver.findElementByLinkText("Junior Developer").click();
            driver.findElementById("sysverb_insert_bottom").click();
            driver.findElementByXPath("//span[@class='icon icon-locked']").click();
			
		
			
		}
		

	}

